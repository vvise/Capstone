package com.example.demo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller // This means that this class is a Controller
@RequestMapping(path = "/cafe") 
public class MainController {
	
	
	@GetMapping("/main")
	public String mainShow1() {
		return "/cafe/main";	
	}
		
		
}
