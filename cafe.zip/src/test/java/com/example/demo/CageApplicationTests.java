package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.domain.Categories;
import com.example.demo.domain.Customer;
import com.example.demo.domain.Product;
import com.example.demo.domain.Product_option_info;
import com.example.demo.persistence.BasketRepository;
import com.example.demo.persistence.CategoriesRepository;
import com.example.demo.persistence.CustomerRepository;
import com.example.demo.persistence.OptionInfoRepo;
import com.example.demo.persistence.ProductImageRepository;
import com.example.demo.persistence.ProductRepository;

@SpringBootTest
class CageApplicationTests {

	@Autowired
	private CustomerRepository CustomerRepo;
	@Autowired
	private ProductRepository ProductRepo;
	@Autowired
	private CategoriesRepository CategoRepo;
	@Autowired
	private BasketRepository basketRepo;
	@Autowired
	private ProductImageRepository ProImgRepo;
	@Autowired
	private ProductImageRepository ImageRepository;
	@Autowired
	private OptionInfoRepo OptionRepository;

//	@Test
//	void insertCustomInfo() {
//		Customer custom = new Customer();
//		custom.setUserId("Qwe123");
//		CustomerRepo.save(custom);
//		
//		custom = new Customer();
//		custom.setUserId("Gcv456");
//		CustomerRepo.save(custom);
//		
//	}
//	@Test
//	   void contextLoads() {
//	      String str_cate[]= {"COFFEE","TEA","JUICE"};
//	      Categories cate[]=new Categories[3];
//	      for (int i = 0; i < 3; i++) {
//	         cate[i]=new Categories();
//	         cate[i].setCategoryName(str_cate[i]);
//	       CategoRepo.save(cate[i]);
//	      }
//	   // 햄버거
//	   Product product = new Product();
//	   product.setProductName("아메리카노");
//	   product.setPrice(1500);
//	   product.setAllSale(false);
//	   product.setCategories(cate[0]);
//	   ProductRepo.save(product);
//
//	   product = new Product();
//	   product.setProductName("얼그레이");
//	   product.setPrice(2500);
//	   product.setAllSale(false);
//	   product.setCategories(cate[1]);
//	   ProductRepo.save(product);
//	   
//	   //커피
//	   product = new Product();
//	   product.setProductName("요커트 스무디");
//	   product.setPrice(3900);
//	   product.setAllSale(false);
//	   product.setCategories(cate[2]);
//	   ProductRepo.save(product);
//	   
//	  
//	      }
	@Test
	void insertProductInfo() {
		Iterable<Product> productList = ProductRepo.findAll();
		for(Product p:productList) {
			for(int i=0; i<2; i++) {
				
			}
		}

	}
//	@Test
//	void sizeadd() {
//		
//		
//	    Size none = new Size();
//	    none.setSizename("None");
//	    SizeRepository.save(none);
//		// 사이즈
//	     Size s = new Size();
//	     s.setSizename("Small");
//	     SizeRepository.save(s);
//	     
//	     Size m = new Size();
//	     m.setSizename("Medium");
//	     SizeRepository.save(m);
//	     
//	     Size l = new Size();
//	     l.setSizename("Large");
//	     SizeRepository.save(l);
//	     
//	     Size tall = new Size();
//	     tall.setSizename("Tall");
//	     SizeRepository.save(tall);
//	     
//	     Size grande = new Size();
//	     grande.setSizename("Grande");
//	     SizeRepository.save(grande);
//	     
//	     Size venti = new Size();
//	     venti.setSizename("Venti");
//	     SizeRepository.save(venti);
//	     
//	     
//	} 
	
//	@Test
//	void tempadd() {
//		
//	
//		// 온도
//		 Temperature none = new Temperature();
//		 none.setTempname("None");
//	     TemperRepo.save(none);
//	     
//		 Temperature hot = new Temperature();
//		 hot.setTempname("Hot");
//	     TemperRepo.save(hot);
//	     
//	     Temperature ice = new Temperature();
//	     ice.setTempname("Ice");
//	     TemperRepo.save(ice);
//	   
//      
//	}
	
}
